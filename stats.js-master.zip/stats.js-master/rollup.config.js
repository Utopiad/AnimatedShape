export default {
  entry: 'src/Stats.js',
  dest: 'build/stats.js',
  moduleName: 'Stats',
  format: 'umd'
};
